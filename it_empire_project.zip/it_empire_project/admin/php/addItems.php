<?php

	if(isset($_POST['submit'])){
								
		error_reporting(1);
		$connection = new mysqli("localhost", "root", "", "itempiredb");

		$name = $_POST['name'];
		$display = $_POST['display'];
		$chip = $_POST['chip'];
		$camera = $_POST['camera'];
		$battery = $_POST['battery'];
		$summary = $_POST['summary'];
		$price = $_POST['price'];
		$image = $_FILES['image']['name'];

		$query = "INSERT INTO shop(Name,Image,Display,Camera,Chip,Battery,Summary,Price) VALUES ('$name','$image','$display','$camera','$chip','$battery', '$summary','$price')";
		$result = mysqli_query($connection,$query); 

		if($result){
			move_uploaded_file($_FILES["image"]["tmp_name"],"../../assets/img/products/".$image);
			header('location:shoplist.php');
		}else{
			echo '<script>alert("Someting Went Wrong!!")</script>';
		}
	}


?>