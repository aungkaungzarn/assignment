<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>

    <!-- logo -->
	<link rel="icon" type="img/png" href="../../assets/img/logo/logo.png" sizes="32x32">

	<!-- Bootstrap css1 js1 -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"/>

	<!-- Fonts Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <style>
        .margins{
			margin-top: 200px;
		}
    </style>
</head>
<body>

    <?php
        $conn = new mysqli("localhost", "root", "", "itempiredb");

        $id = $_GET['id'];

        if(isset($_POST['update'])){
            $name = $_POST['name'];
            $display = $_POST['display'];
            $chip = $_POST['chip'];
            $camera = $_POST['camera'];
            $price = $_POST['price'];

            $update = "UPDATE shop SET Name='$name',Display='$display',Chip='$chip',Camera='$camera',Price='$price' where id=$id";

            $conn->query($update);
            header('location:shoplist.php');
        }

        if(isset($_POST['cancel'])){
            header('location:shoplist.php');
        }
    ?>

        <div class="container d-flex align-items-center justify-content-center">
			<div class="row margins">
				<div class="col-12">
					<div class="card-group">
						<div class="card">
							<div class="card-header text-center h3">
								Product
							</div>
							<?php 
								$conn = new mysqli('localhost','root','','itempiredb');

								$id = $_GET['id'];

								$data = "SELECT * FROM shop WHERE id=$id";
								$val = $conn->query($data);

								if ($val){
									while(list($id,$name,$img,$display,$camera,$chipset,$battery,$summary,$price) = mysqli_fetch_array($val)){
										echo "
											<img src='../../assets/img/products/$img' alt='$img'>
										";
									}
								}
							?>
						</div>

						<div class="card">
							<div class="card-header text-center h3">
								Order Information
							</div>
							<div class="card-body">
                                <?php 
                                    $conn = new mysqli('localhost','root','','itempiredb');

                                    $id = $_GET['id'];

                                    $data = "SELECT * FROM shop WHERE id=$id";
                                    $val = $conn->query($data);

                                    if ($val){
                                        while(list($id,$name,$img,$display,$camera,$chipset,$battery,$summary,$price) = mysqli_fetch_array($val)){
                                            echo "
                                                <form method='POST'>
                                                    <div class='mb-3'>
                                                        <label for='name' class='form-label'>Product Name</label>
                                                        <input type='text' name='name' id='name' class='form-control' value='$name'>
                                                    </div>
                                                    <div class='mb-3'>
                                                        <label for='display' class='form-label'>Diplay Sizes</label>
                                                        <input type='text' name='display' id='display' class='form-control' value='$display'>
                                                    </div>
                                                    <div class='mb-3'>
                                                        <label for='camera' class='form-label'>Camera</label>
                                                        <input type='text' name='camera' id='camera' class='form-control' value='$camera'>
                                                    </div>
                                                    <div class='mb-3'>
                                                        <label for='chip' class='form-label'>Chipset</label>
                                                        <input type='text' name='chip' id='chip' class='form-control' value='$chipset'>
                                                    </div>
                                                    <div class='mb-3'>
                                                        <label for='price' class='form-label'>Price</label>
                                                        <input type='text' name='price' id='price' class='form-control' value='$price'>
                                                    </div>
                                                    <div class='text-end'>
                                                        <button type='submit' name='cancel' id='cancel' class='btn btn-danger'>Cancel</button>
                                                        <button type='submit' name='update' id='confirm' class='btn btn-secondary'>Update</button>
                                                    </div>
                                                </form>
                                            ";
                                        }
                                    }
                                ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

</body>
</html>

