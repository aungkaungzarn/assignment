<?php
    $conn = new mysqli('localhost','root','','itempiredb');
    $delete = "delete from shop where id ='{$_GET['id']}'";
    $conn->query($delete);
    unlink("../../assets/img/products/".$_GET['img']);
    header('location:shoplist.php');
?>