<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>

    <!-- logo -->
	<link rel="icon" type="img/png" href="../../assets/img/logo/logo.png" sizes="32x32">

    <!-- Bootstrap css1 js1 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"/>

    <!-- Fonts Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

	<style>

		
	</style>

</head>
<body>

    <header>
        <!-- Start navbar -->
		<nav class="navbar navbar-expand-md bg-dark navbar-dark fixed-top">
			<div class="col-md-3">
				<a href="shoplist.php" class="navbar-brand mx-3">
					<img src="../../assets/img/logo/logo.png" width="50px" alt="sitelogo">
					<span class="ms-2 fw-bolder">IT Empire</span>
				</a>
			</div>

			<button type="button" class="navbar-toggler me-3" data-bs-toggle="collapse" data-bs-target=".navs"><i class="navbar-toggler-icon"></i></button>

				<div id="nav" class="navbar-collapse collapse col-md-6 justify-content-center navs">
					<ul class="navbar-nav px-3">
						<li class="nav-item"><a href="./shoplist.php" class="nav-link text-uppercase fw-bold">Shop</a></li>
						<li class="nav-item"><a href="./order.php" class="nav-link active text-uppercase fw-bold">Order</a></li>
						<li class="nav-item"><a href="./contact.php" class="nav-link text-uppercase fw-bold">contact</a></li>
					</ul>
				</div>
	
				<div class="navbar-collapse collapse col-md-3 my-2 text-light justify-content-end navs">
					<span>1 USD <img src="../../assets/img/flag/usa.png" class="ms-2" alt="us" width="20px"> &nbsp; = &nbsp;</span>
					<span>6000 MKK <img src="../../assets/img/flag/mm.png" class="ms-2 me-4" alt="mm" width="20px"></span>
				</div>
		</nav> 
		<!-- End navbar -->
    </header>
	

	<!-- Start Order Body Section -->
	<section>
		<div class="container">

			<div class="row">
				<div class="col-12 pt-3 mt-5">
					<table class="table table-hover caption-top">
						<caption class="h1 mb-4">Order Lists</caption>
						<thead class="table-secondary">
							<tr>
								<th>No</th>
								<th>Name</th>
								<th>Phone Number</th>
								<th>Address</th>
								<th>Price</th>
							</tr>
						</thead>
						<tbody>
						<?php
							error_reporting(1);
							$conn = new mysqli('localhost','root','','itempiredb');

							$data = "SELECT * FROM orderlist ORDER BY id DESC";
							$val = $conn->query($data);
							$i = 1;

							if($val->num_rows > 0){
								while(list($id,$name,$phone,$address,$price)= mysqli_fetch_array($val)){
									echo "
										<tr>
											<td>".$i++."</td>
											<td>".$name."</td>
											<td>".$phone."</td>
											<td>".$address."</td>
											<td>".$price."</td>
										</tr>
									";
								}
							}else{
								echo "<tr><td colspan='7' class='text-center'>
								<b> No data available</b></td></tr>";
							}
						?>
						</tbody>
					</table>
				</div>
			</div>

		</div>
	</section>
	<!-- End Order Body Section -->



    <!-- Bootstrap css1 js1 -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>