<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IT Empire | Admin Login</title>
    
    <!-- logo -->
	<link rel="icon" type="img/png" href="../assets/img/logo/logo.png" sizes="32x32">

    <!-- Bootstrap css1 js1 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"/>

    <!-- Fonts Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <style type="text/css">

        .banners{
            height: 100vh;
            background: linear-gradient(
                20deg,
                rgb(0, 0, 0) 20%,
                rgb(255, 255, 255) 5%
            );

            background-size: 3%;
            transition: all 2s;
        }

        .banners:hover{
            background-size: 3.3%;
            background-position: center;
        }

    </style>

</head>
<body>

    <?php

        error_reporting(1);
        if (isset($_GET['sub'])) {
            $eid = $_GET['userName'];
            $pass = $_GET['password'];

            if ($eid == '' || $pass == '') {
                echo "<script>alert('Please fill username or password');</script>";
            } else {
                if ($eid == "admin" && $pass == "superuser") {
                    header('location:./php/shoplist.php');
                } else {
                    echo "<script>alert('username or password Wrong!');</script>";
                }
            }
        }

    ?>

    <div class="container-fluid">
        <div class="row justify-content-center align-items-center banners">
            <div class="col-sm-2 col-md-5"></div>
            <div class="col-sm-8 col-md-2 mrs">
                <form>
                    <div class="form-group text-center">
                        <img src="../assets/img/logo/sitelogo.webp" alt="sitelogo">
                    </div>
                    <div class="form-group mb-3">
                        <label for="userName" class="mb-1 fw-bolder">Username</label>
                        <input type="text" name="userName" id="userName" class="form-control form-control-sm" placeholder="Enter your username">
                    </div>

                    <div class="form-group mb-3">
                        <label for="password" class="mb-1 fw-bolder">Password</label>
                        <input type="password" name="password" id="password" class="form-control form-control-sm" placeholder="Enter your password">
                    </div>

                    <div class="row">
                        <div class="col-md-3"></div>
                        <div class="col-md-6">
                            <button type="submit" name="sub" class="btn btn-dark col-12">Log In</button>
                        </div>
                        <div class="col-md-3"></div>
                    </div>
                </form> 
            </div>
            <div class="col-sm-2 col-md-5"></div>
        </div>
    </div>

    <!-- Bootstrap css1 js1 -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>