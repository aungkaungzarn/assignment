<!DOCTYPE html>
<html>
<head>
	<title>IT Empire</title>

	<!-- logo -->
	<link rel="icon" type="img/png" href="../../assets/img/logo/logo.png" sizes="32x32">

	<!-- Bootstrap css1 js1 -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"/>

	<!-- Fonts Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

	<style type="text/css">
		
		.margins{
			margin-top: 50px;
		}

		.navs span{
			font-size: 15px;
		}
		
		.card:hover{
			cursor: pointer;
		}

	</style>
</head>
<body>

	<!-- Start Header Section -->
	<header>
		<!-- Start navbar -->
		<nav class="navbar navbar-expand-md bg-dark navbar-dark fixed-top">
			<div class="col-md-3">
				<a href="../../index.html" class="navbar-brand mx-3">
					<img src="../../assets/img/logo/logo.png" width="50px" alt="sitelogo">
					<span class="ms-2 fw-bolder">IT Empire</span>
				</a>
			</div>

			<button type="button" class="navbar-toggler me-3" data-bs-toggle="collapse" data-bs-target=".navs"><i class="navbar-toggler-icon"></i></button>

			<div id="nav" class="navbar-collapse collapse col-md-6 justify-content-center navs">
				<ul class="navbar-nav px-3">
					<li class="nav-item"><a href="../../index.html" class="nav-link text-uppercase fw-bold">Home</a></li>
					<li class="nav-item"><a href="./shop.php" class="nav-link active text-uppercase fw-bold">Shop</a></li>
					<li class="nav-item"><a href="./community.html" class="nav-link text-uppercase fw-bold">Community</a></li>
					<li class="nav-item"><a href="./about.html" class="nav-link text-uppercase fw-bold">About</a></li>
				</ul>
			</div>

			<div class="navbar-collapse collapse col-md-3 my-2 text-light justify-content-end navs">
				<span>1 USD <img src="../../assets/img/flag/usa.png" class="ms-2" alt="us" width="20px"> &nbsp; = &nbsp;</span>
				<span>6000 MKK <img src="../../assets/img/flag/mm.png" class="ms-2 me-4" alt="mm" width="20px"></span>
			</div>

		</nav> 
		<!-- End navbar -->
	</header>
	<!-- End Header Section -->

	<!-- Start Shop Section -->
	<section>
		<!-- Start shop body section-->
		<div class="container-fluid p-5 margins">

			<div class="row">

				<?php

					error_reporting(1);
					include('../connection/connection.php');

					$data = "SELECT * FROM shop ORDER BY id DESC";
					$val = $con->query($data);

					$pName = $_POST['Name'];

					if ($val->num_rows>0) {
						while(list($id,$name,$img,$display,$camera,$chipset,$battery,$summary,$price) = mysqli_fetch_array($val)){

							echo"
							<div class='col-sm-12 col-md-3 mb-3'>
								<div class='card p-3'>
									<img src='../../assets/img/products/$img' alt='$img'>
									<div class='card-body'>
										<p class='card-title fw-bolder text-center'>$name</p>
										<!-- <hr> -->
										<div class='card-text'>
											<p><span class='fw-bolder'>Display</span> - <span>$display \"</span></p>
											<p><span class='fw-bolder'>Camera</span> - <span>$camera MP</span></p>
											<p><span class='fw-bolder'>Chipset</span> - <span>$chipset</span></p>
											<p><span class='fw-bolder'>Battery Life</span> - <span>$battery mAH</span></p>
											<p><span class='fw-bolder'>Summary</span> - <span>$summary</span></p>
										</div>

										<hr>

										<div class='d-flex flex-wrap justify-content-between'>
											<span class='fw-bold'>Price - $$price</span>
											<a href='../php/buyNow.php?id=$id&price=$price' class='btn btn-secondary btn-sm ms-5'>Buy Now</a>
										</div>
									</div>
								</div>
							</div>
						";
						}
					}else{
						echo "<h1 colspan='8' class='text-center'>
						<b> No data available</b></h1>
						";
					}

				?>

			</div>

		</div>
		<!-- End shop body section -->
	</section>
	<!-- End Shop Section -->

	<!-- Start Footer Section -->
	<div class="container-fluid">
		<footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
			<div class="col-md-4 d-flex align-items-center">
				<a href="/" class="mb-3 me-2 mb-md-0 text-body-secondary text-decoration-none lh-1">
					<img src="../../assets/img/logo/logo.png" class="bi" width="30" height="30">
				</a>
				<span class="mb-3 mb-md-0 text-body-secondary">Copyright © 2024 | IT Empire</span>
			</div>
	
			<ul class="nav col-md-4 justify-content-end list-unstyled d-flex">
				<li class="ms-3"><a class="text-body-secondary" href="#"><i class="fa-brands fa-facebook bi" width="30" height="30" alt="Facebook" title="Facebook"></i></a></li>
				<li class="ms-3"><a class="text-body-secondary" href="#"><i class="fa-brands fa-x-twitter bi" width="30" height="30" alt="Twitter" title="Twitter"></i></a></li>
				<li class="ms-3"><a class="text-body-secondary" href="#"><i class="fa-brands fa-instagram bi" width="30" height="30" alt="Instagram" title="Instagram"></i></a></li>
			</ul>
		</footer>
	</div>
	<!-- End Footer Section -->



	<!-- Bootstrap css1 js1 -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>