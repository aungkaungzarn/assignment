<?php

    error_reporting(1);
    include('../connection/connection.php');

    if(isset($_POST['submit'])){
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $message = $_POST['message'];

        $query = "INSERT INTO `contact` VALUES ('','$name','$email','$phone','$message')";
        $con->query($query);

        echo "<script>alert('Message Sent Successfully!')</script>";
        header('location:../../index.html');
    }

?>