<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IT Empire</title>

    <!-- logo -->
	<link rel="icon" type="img/png" href="../../assets/img/logo/logo.png" sizes="32x32">

	<!-- Bootstrap css1 js1 -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"/>

	<!-- Fonts Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

	<style>

		.margins{
			margin-top: 200px;
		}

	</style>

</head>
<body>

    <section>

		<?php
			$connection = new mysqli('localhost','root','','itempiredb');

			if(isset($_POST['confirm'])){
				$fName = $_POST['fullName'];
				$phone = $_POST['phone'];
				$address = $_POST['address'];
				$price = $_GET['price'];

				$data = "INSERT INTO orderlist (Name,Phone,Address,Price) VALUES ('$fName','$phone','$address','$price')";
				$connection->query($data);
				header('location:../pages/shop.php');
			}

			if(isset($_POST['cancel'])){
				header('location:../pages/shop.php');
			}
		?>

        <div class="container d-flex align-items-center justify-content-center">
			<div class="row margins">
				<div class="col-12">
					<div class="card-group">
						<div class="card">
							<div class="card-header text-center h3">
								Product
							</div>
							<?php 
								$conn = new mysqli('localhost','root','','itempiredb');

								$id = $_GET['id'];

								$data = "SELECT * FROM shop WHERE id=$id";
								$val = $conn->query($data);

								if ($val){
									while(list($id,$name,$img,$display,$camera,$chipset,$battery,$summary,$price) = mysqli_fetch_array($val)){
										echo "
											<img src='../../assets/img/products/$img' alt='$img'>
										";
									}
								}
							?>
						</div>

						<div class="card">
							<div class="card-header text-center h3">
								Order Information
							</div>
							<div class="card-body">
								<form method="POST">
									<div class="mb-3">
										<label for="fullName" class="form-label">Fullname</label>
										<input type="text" name="fullName" id="fullName" class="form-control">
									</div>
									<div class="mb-3">
										<label for="phone" class="form-label">Phone Number</label>
										<input type="text" name="phone" id="phone" class="form-control">
									</div>
									<div class="mb-3">
										<label for="pPrice" class="form-label">Price</label>
										<input type="text" name="pPrice" id="pPrice" class="form-control" value="<?php echo $price = $_GET['price']; ?>" readonly>
									</div>
									<div class="mb-3">
										<label for="address" class="form-label">Address</label>
										<input type="text" name="address" id="address" class="form-control">
									</div>
									<div class="text-end">
										<button type="submit" name="cancel" id="cancel" class="btn btn-danger">Cancel</button>
										<button type="submit" name="confirm" id="confirm" class="btn btn-secondary">Confirm</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
    </section>


    <!-- Bootstrap css1 js1 -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>